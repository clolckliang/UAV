#ifndef __ANOROS_HPP__
#define __ANOROS_HPP__

#include "anolink.hpp"


struct sMsgImu {
    float acc[3];
    float gyr[3];
    float ori[4];
    bool flagMemsReady;
    bool flagOriReady;
};
struct sMsgMag {
    float x;
    float y;
    float z;
};
struct sMsgSpd {
    float x;
    float y;
    float z;
};
struct sMsgOF {
    float x;
    float y;
    float z;
};

extern sMsgImu anoMsgImu;
extern sMsgMag anoMsgMag;
extern sMsgSpd anoMsgImuSpd;
extern sMsgOF anoMsgOF;
extern float anoMsgTmp;
extern float anoMsgAlt;
extern float anoMsgBar;
extern float anoMsgDDist;

void pubMsgImu(void);

void pubMsgMag(void);

void pubMsgTmp(void);

void pubMsgAlt(void);

void pubMsgImuSpd(void);

void pubMsgOF(void);

void rxMsgPosVel(const geometry_msgs::msg::Point::SharedPtr pos );

void rxMsgCmdVel(const geometry_msgs::msg::Twist::SharedPtr msg);

void pubMsgCmdVel(const float lx, const float ly, const float lz, const float ax, const float ay, const float az);

#endif