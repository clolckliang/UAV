#ifndef __ANOLINK_HPP__
#define __ANOLINK_HPP__

#include <chrono>
// #include <geometry_msgs/msg/detail/point__struct.hpp>
#include <rclcpp/subscription.hpp>
#include <thread>

#include "AnoPTv8.hpp"
#include "AnoPTv8ExAPI.hpp"
#include "anoSerial.hpp"B
#include "anoUdp.hpp"
#include "geometry_msgs/msg/twist_stamped.hpp"
#include "geometry_msgs/msg/point.hpp"
#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/imu.hpp"
#include "sensor_msgs/msg/magnetic_field.hpp"
#include "sensor_msgs/msg/temperature.hpp"
#include "sensor_msgs/msg/range.hpp"
#include "tf2_ros/buffer.h"
#include "tf2_ros/transform_listener.h"

class AnoLink : public rclcpp::Node {
public:
    struct sSettings {
        std::string serialName_FC;
        uint32_t serialBaud_FC;
        uint16_t udpPortUpPc;
        std::string pubTopicNameImu;
        std::string pubTopicNameMag;
        std::string pubTopicNameTmp;
        std::string pubTopicNameAlt;
        std::string pubTopicNameDDist;
        std::string pubTopicNameImuVel;
        std::string pubTopicNameOF;
        std::string pubTopicNameCmdVel;
        std::string subTopicNameCmdVel;
        std::string subTopicNamePosSLAM;
        std::string subTopicNamePos1;
        std::string subTopicNamePos2;
    };

public:
    AnoLink(std::string name);
    static AnoLink* m_self;
    sSettings m_set;
    AnoSerial* m_serialFC;
    AnoUdp* m_udpUpPc;

    rclcpp::Publisher<sensor_msgs::msg::Imu>::SharedPtr m_pubImu;
    rclcpp::Publisher<sensor_msgs::msg::MagneticField>::SharedPtr m_pubMag;
    rclcpp::Publisher<sensor_msgs::msg::Temperature>::SharedPtr m_pubTmp;
    rclcpp::Publisher<sensor_msgs::msg::Range>::SharedPtr m_pubAlt;
    rclcpp::Publisher<sensor_msgs::msg::Range>::SharedPtr m_pubDDist;
    rclcpp::Publisher<geometry_msgs::msg::TwistStamped>::SharedPtr m_pubImuVel;
    rclcpp::Publisher<geometry_msgs::msg::TwistStamped>::SharedPtr m_pubCmdVel;

    void RxV8FrameCB(const uint8_t linktype, const _un_frame_v8* p);
private:
    rclcpp::TimerBase::SharedPtr m_runTimer;

    tf2_ros::Buffer::SharedPtr m_tfBuf;
    std::shared_ptr<tf2_ros::TransformListener> m_tfListener;

    rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr m_subTwist;
    rclcpp::Subscription<geometry_msgs::msg::Point>::SharedPtr m_subPos;
    std::thread* m_threadRun;

    void rosTimerCB1ms(void);
    void runThread(void);
    void tfListenerCheck(void);
};

#endif